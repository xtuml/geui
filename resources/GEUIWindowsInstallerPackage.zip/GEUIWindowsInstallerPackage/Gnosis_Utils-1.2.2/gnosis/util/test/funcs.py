import os, sys, string

def pyver():
    return string.split(sys.version)[0] 
