=====GEUI=WINDOWS=INSTALLER=PACKAGE=====

GEUI Required Packages:

Python 2.7.5
Web.py
Gnosis_Utils-1.2.2



To Install GEUI Application:

1. If python 2.7.5 is already installed, execute install.bat
2. If python 2.7.5 is not installed, execute install_with_python.bat



To Run GEUI Application:

1. Navigate to geui/application/
2. Run server.py
3. Connect to "localhost:8080" in a web browser (Google Chrome is the most extensively tested browser)
